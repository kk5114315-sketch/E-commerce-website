# MarketNest: Multi-Vendor E-Commerce Website

A responsive e-commerce marketplace built as a practical virtual internship project (Full Stack Development).
Plain HTML, CSS and JavaScript, no build step. Data is stored in the browser database (localStorage).

**Live demo:** add your deployed link here

## Features
- 36 sample products in 6 categories with **smart search** (name, brand, category, synonyms and small typos: "earphones" finds headphones, "shoes" finds footwear)
- Live search suggestions, category chips, price and rating filters, sorting
- Product page with stock status, quantity, Add to Cart, Buy Now, wishlist and similar products
- Cart with quantity limits, coupon `WELCOME10` and delivery charge rules
- Signup and login with validation, protected Checkout, Orders and Dashboard pages
- Checkout with address validation and a mock payment flow (UPI, Card, Cash on Delivery)
- Orders page with status timeline and cancel option
- Seller dashboard: product CRUD with validation, search, and order status updates
- Responsive layout, toasts, 404 page

## Demo accounts
Seller: `seller@marketnest.com` / `seller123` (or use the "Login as Seller" button). Customers can sign up.

## Run locally
Open `index.html` in a browser.

## Deploy
Upload the folder to GitHub, then enable **Settings → Pages** (branch `main`, root). Or drag the folder to Netlify Drop.

## Database note
All data lives in `localStorage` (see the data section at the top of `app.js`). To use a real backend (Express, MongoDB, JWT), replace `LS.get`, `LS.set` and the `save()` calls with `fetch()` calls to your API. Passwords here are only base64-encoded for the demo. Never do this in production: use bcrypt on the server.

## Structure
`index.html` · `style.css` · `app.js` · `README.md`
