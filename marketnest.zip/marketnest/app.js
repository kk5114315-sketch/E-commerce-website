'use strict';
/* ===== helpers ===== */
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const inr = n => '₹' + Number(n).toLocaleString('en-IN');
const LS = {get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
            set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }};
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('on'), 2000); }

/* ===== data (browser database: localStorage) ===== */
const CATS = {'Electronics':'🎧','Fashion & Bags':'👜','Footwear':'👟','Beauty & Wellness':'🧴','Fitness & Yoga':'🧘','Stationery & Desk':'✏️'};
const RAW = {
'Electronics':`boAt Rockerz Bluetooth Headphones|boAt|1499|2999|headphones earphones earbuds headset bluetooth audio
Noise Wireless Earbuds|Noise|1299|3499|earphones earbuds tws wireless audio headset
Mi Power Bank 20000mAh|Mi|1799|2499|powerbank charger battery
Fire-Boltt Smart Watch|Fire-Boltt|1999|7999|smartwatch watch fitness band
Portronics Bluetooth Speaker|Portronics|999|2499|speaker bluetooth music audio
Logitech Wireless Mouse|Logitech|699|1295|mouse computer laptop accessories`,
'Fashion & Bags':`Wildcraft Laptop Backpack|Wildcraft|1199|2499|bag backpack school college laptop
Allen Solly Cotton T-Shirt|Allen Solly|599|1299|tshirt shirt clothes men
Levis Slim Fit Jeans|Levis|1799|3499|jeans pant denim clothes
Lavie Women Handbag|Lavie|899|1999|handbag purse bag women
Fabindia Cotton Kurta|Fabindia|1099|2199|kurta ethnic clothes
Fastrack Sunglasses|Fastrack|799|1599|sunglasses goggles shades`,
'Footwear':`Campus Running Shoes|Campus|1299|2499|shoes sneakers running sports
Puma Casual Sneakers|Puma|1999|4499|shoes sneakers casual
Bata Formal Shoes|Bata|1499|2699|shoes formal office
Sparx Flip Flops|Sparx|299|599|chappal slippers flipflop
Adidas Sports Sandals|Adidas|999|1999|sandals chappal
Woodland Leather Boots|Woodland|2999|4999|boots shoes trekking`,
'Beauty & Wellness':`Lakme Face Moisturizer|Lakme|349|550|cream skincare face
Mamaearth Vitamin C Serum|Mamaearth|499|799|serum skincare face
Dove Shampoo 650ml|Dove|399|620|shampoo hair care
Biotique Face Wash|Biotique|199|320|facewash skincare
Maybelline Lipstick|Maybelline|399|650|lipstick makeup
Nivea Body Lotion|Nivea|299|450|lotion bodycare skin`,
'Fitness & Yoga':`Boldfit Yoga Mat 6mm|Boldfit|499|1299|yoga mat exercise
Kore Dumbbell Set 10kg|Kore|1499|2999|dumbbell weights gym
Cockatoo Skipping Rope|Cockatoo|199|499|rope cardio
Boldfit Resistance Bands|Boldfit|399|999|bands workout
MuscleBlaze Shaker Bottle|MuscleBlaze|249|499|shaker bottle gym protein
Mi Fitness Band|Mi|1699|2999|band tracker fitness`,
'Stationery & Desk':`Classmate Notebook Pack of 6|Classmate|299|420|notebook copy diary
Parker Gel Pen Set|Parker|199|350|pen pens writing
Wipro LED Desk Lamp|Wipro|799|1499|lamp light desk
Casio Scientific Calculator|Casio|899|1195|calculator maths
Wooden Desk Organizer|Urban|549|999|organizer stationery
Camlin Geometry Box|Camlin|149|250|geometry compass school`};
const SELL = ['TechHub India','StyleKart Traders','UrbanNest Store','FitLife Sellers','Desi Mart'];
function seed() {
  const out = []; let i = 0;
  for (const [cat, lines] of Object.entries(RAW)) for (const l of lines.split('\n')) {
    const [name, brand, price, mrp, tags] = l.split('|'); i++;
    out.push({id:'p' + i, name, brand, cat, price:+price, mrp:+mrp, tags, stock:5 + (i * 3) % 40, rating:+(3.8 + (i * 7) % 12 / 10).toFixed(1), seller:SELL[i % 5], icon:CATS[cat], desc:name + ' by ' + brand + '. Quality product from a verified seller with easy returns and fast delivery.'});
  }
  return out;
}
let P = LS.get('mn_products', null) || seed();
let U = LS.get('mn_users', null) || [{name:'Demo Seller', email:'seller@marketnest.com', pass:btoa('seller123'), role:'seller'}];
let S = LS.get('mn_session', null), C = LS.get('mn_cart', []), W = LS.get('mn_wish', []), O = LS.get('mn_orders', []);
const save = () => { LS.set('mn_products', P); LS.set('mn_users', U); LS.set('mn_session', S); LS.set('mn_cart', C); LS.set('mn_wish', W); LS.set('mn_orders', O); };
save();
const find = id => P.find(p => p.id === id);
let F = {q:'', cat:'', max:0, rating:0, sort:'rel'}, coupon = '', next = '', mode = 'login', Q = new URLSearchParams(), editId = '';
const ST = ['Placed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];
const stage = o => o.cancelled ? -1 : (o.manual != null ? o.manual : Math.min(4, Math.floor((Date.now() - o.created) / 30000)));

/* ===== smart search (name, brand, category, tags, synonyms, small typos) ===== */
function lev(a, b) {
  const d = Array.from({length:a.length + 1}, (_, i) => [i]); for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i-1][j] + 1, d[i][j-1] + 1, d[i-1][j-1] + (a[i-1] === b[j-1] ? 0 : 1));
  return d[a.length][b.length];
}
function match(p, q) {
  const toks = q.toLowerCase().split(/\s+/).filter(Boolean); if (!toks.length) return true;
  const hay = (p.name + ' ' + p.brand + ' ' + p.cat + ' ' + p.tags).toLowerCase(), words = hay.split(/[^a-z0-9]+/);
  return toks.every(t => hay.includes(t) || (t.length > 3 && hay.includes(t.replace(/s$/, ''))) || (t.length > 3 && words.some(w => Math.abs(w.length - t.length) < 2 && lev(w, t) < 2)));
}
const rank = p => F.q && p.name.toLowerCase().includes(F.q.toLowerCase()) ? 0 : 1;
function list() {
  const sorts = {rel:(a, b) => rank(a) - rank(b), pl:(a, b) => a.price - b.price, ph:(a, b) => b.price - a.price, rt:(a, b) => b.rating - a.rating};
  return P.filter(p => (!F.cat || p.cat === F.cat) && (!F.max || p.price <= F.max) && p.rating >= F.rating && match(p, F.q)).sort(sorts[F.sort]);
}

/* ===== cart maths ===== */
function tot() {
  C = C.filter(l => find(l.id));
  const sub = C.reduce((s, l) => s + find(l.id).price * l.qty, 0), mrp = C.reduce((s, l) => s + find(l.id).mrp * l.qty, 0);
  const disc = coupon === 'WELCOME10' ? Math.round(sub * .1) : 0, ship = !sub || sub - disc >= 499 ? 0 : 49;
  return {sub, mrp, disc, ship, total:sub - disc + ship};
}
function add(id, q = 1) {
  const p = find(id), l = C.find(x => x.id === id), n = (l ? l.qty : 0) + q;
  if (n > p.stock) return toast('Only ' + p.stock + ' in stock');
  l ? l.qty = n : C.push({id, qty:q}); save(); hdr(); toast('Added to cart');
}

/* ===== views ===== */
const off = p => Math.round((1 - p.price / p.mrp) * 100);
const stars = r => '★ ' + r.toFixed(1);
function card(p) {
  return `<article class="card"><a href="#/product/${p.id}"><div class="ph">${p.icon}</div></a><button class="heart" data-act="wish" data-id="${p.id}" aria-label="Wishlist">${W.includes(p.id) ? '❤️' : '🤍'}</button>
  <h3><a href="#/product/${p.id}">${esc(p.name)}</a></h3><div class="mut">${esc(p.brand)} · ${stars(p.rating)}</div>
  <div><span class="pr">${inr(p.price)}</span><span class="mrp">${inr(p.mrp)}</span><span class="off">${off(p)}% off</span></div>
  <button class="pri" data-act="add" data-id="${p.id}" ${p.stock < 1 ? 'disabled' : ''}>${p.stock < 1 ? 'Out of stock' : 'Add to cart'}</button></article>`;
}
function vHome() {
  const r = list(), sel = (k, arr) => arr.map(([v, t]) => `<option value="${v}" ${String(F[k]) === String(v) ? 'selected' : ''}>${t}</option>`).join('');
  return `${F.q || F.cat ? '' : '<div class="hero"><h1>Shop smarter from India’s sellers</h1><p>Try searching “earphones”, “shoes” or “yoga”.</p></div>'}
  <div class="chips"><span class="chip ${F.cat ? '' : 'on'}" data-act="cat" data-v="">All</span>${Object.keys(CATS).map(c => `<span class="chip ${F.cat === c ? 'on' : ''}" data-act="cat" data-v="${esc(c)}">${CATS[c]} ${esc(c)}</span>`).join('')}</div>
  <div class="fb"><select data-f="max" aria-label="Max price">${sel('max', [[0, 'Any price'], [500, 'Under ₹500'], [1000, 'Under ₹1,000'], [2000, 'Under ₹2,000'], [5000, 'Under ₹5,000']])}</select>
  <select data-f="rating" aria-label="Rating">${sel('rating', [[0, 'Any rating'], [4, '4★ & above'], [4.5, '4.5★ & above']])}</select>
  <select data-f="sort" aria-label="Sort">${sel('sort', [['rel', 'Relevance'], ['pl', 'Price: low to high'], ['ph', 'Price: high to low'], ['rt', 'Top rated']])}</select></div>
  <p class="mut">${r.length} result${r.length === 1 ? '' : 's'}${F.q ? ` for “${esc(F.q)}”` : ''}</p>
  ${r.length ? `<section class="grid">${r.map(card).join('')}</section>` : `<div class="empty">No products found. Try “earphones”, “shoes”, “bag” or clear the filters.<br><br><button data-act="clear">Clear filters</button></div>`}`;
}
function vProduct(id) {
  const p = find(id); if (!p) return v404();
  const sim = P.filter(x => x.cat === p.cat && x.id !== id).slice(0, 4);
  return `<div class="two"><div class="ph big">${p.icon}</div><div><h1>${esc(p.name)}</h1><p class="mut">by ${esc(p.brand)} · sold by ${esc(p.seller)} · ${stars(p.rating)}</p>
  <p><span class="pr" style="font-size:1.6rem">${inr(p.price)}</span><span class="mrp">${inr(p.mrp)}</span><span class="off">${off(p)}% off</span></p>
  <p>${p.stock < 1 ? '<span class="tag" style="color:var(--bad)">Out of stock</span>' : p.stock < 6 ? `<span class="tag" style="color:var(--warn)">Only ${p.stock} left</span>` : '<span class="tag ok">In stock</span>'}</p><p>${esc(p.desc)}</p>
  <div class="row" style="justify-content:flex-start"><button class="pri" data-act="add" data-id="${p.id}" ${p.stock < 1 ? 'disabled' : ''}>Add to cart</button><button data-act="buy" data-id="${p.id}" ${p.stock < 1 ? 'disabled' : ''}>Buy now</button><button data-act="wish" data-id="${p.id}">${W.includes(p.id) ? '❤️ Wishlisted' : '🤍 Wishlist'}</button></div></div></div>
  <h2 style="margin:20px 0 10px">Similar products</h2><section class="grid">${sim.map(card).join('')}</section>`;
}
function vCart() {
  const t = tot(); if (!C.length) return `<div class="empty">Your cart is empty.<br><br><a href="#/"><button class="pri">Start shopping</button></a></div>`;
  return `<h2>Shopping cart</h2><div class="cols"><div class="panel">${C.map(l => { const p = find(l.id); return `<div class="line row"><div>${p.icon} <a href="#/product/${p.id}"><b>${esc(p.name)}</b></a><div class="mut">${inr(p.price)} each</div></div>
  <div class="row"><button data-act="qty" data-id="${p.id}" data-d="-1">−</button><b>${l.qty}</b><button data-act="qty" data-id="${p.id}" data-d="1">+</button><button class="dng" data-act="rm" data-id="${p.id}">Remove</button></div></div>`; }).join('')}</div>
  <div class="panel"><h3>Price details</h3><div class="row line"><span>Price (MRP)</span><span>${inr(t.mrp)}</span></div><div class="row line"><span>Discount</span><span class="off">− ${inr(t.mrp - t.sub + t.disc)}</span></div>
  <div class="row line"><span>Delivery</span><span>${t.ship ? inr(t.ship) : 'FREE'}</span></div><div class="row line"><b>Total</b><b>${inr(t.total)}</b></div>
  <div class="row" style="margin:10px 0"><input id="cp" placeholder="Coupon (WELCOME10)" value="${esc(coupon)}" style="flex:1"><button data-act="coupon">Apply</button></div>
  <a href="#/checkout"><button class="pri" style="width:100%">Proceed to checkout</button></a></div></div>`;
}
const vWish = () => `<h2>My wishlist</h2>${W.length ? `<section class="grid">${W.map(find).filter(Boolean).map(p => card(p).replace('Add to cart', 'Move to cart').replace('data-act="add"', 'data-act="move"')).join('')}</section>` : '<div class="empty">Your wishlist is empty. Tap the heart on any product.</div>'}`;
function vAuth() {
  const su = mode === 'signup';
  return `<div class="panel" style="max-width:420px;margin:auto"><h2>${su ? 'Create account' : 'Login'}</h2><form id="af" novalidate>
  ${su ? '<div class="f"><label>Name</label><input name="name"><small class="err" data-e="name"></small></div>' : ''}
  <div class="f"><label>Email</label><input name="email" type="email" autocomplete="email"><small class="err" data-e="email"></small></div>
  <div class="f"><label>Password (min 6 characters)</label><input name="pass" type="password"><small class="err" data-e="pass"></small></div>
  <label class="mut"><input type="checkbox" data-act="showpw"> Show password</label><br><br><button class="pri" style="width:100%">${su ? 'Sign up' : 'Login'}</button></form>
  <p class="mut">${su ? 'Have an account?' : 'New here?'} <a href="#" data-act="mode" style="color:var(--ac)">${su ? 'Login' : 'Create account'}</a></p>
  <button data-act="demo" style="width:100%">Login as Seller (demo)</button></div>`;
}
function vCheckout() {
  const t = tot(); if (!C.length) return `<div class="empty">Your cart is empty.</div>`;
  return `<h2>Checkout</h2><div class="cols"><form id="co" class="panel" novalidate><h3>Delivery address</h3>
  ${[['name', 'Full name'], ['phone', 'Phone (10 digits)'], ['pin', 'Pincode (6 digits)'], ['addr', 'Address'], ['city', 'City']].map(([n, l]) => `<div class="f"><label>${l}</label><input name="${n}"><small class="err" data-e="${n}"></small></div>`).join('')}
  <h3>Payment</h3><div class="f"><select name="pay"><option>UPI</option><option>Card</option><option>Cash on Delivery</option></select></div>
  <p class="mut">Demo payment: no real money is charged.</p><small class="err" id="pe"></small><button class="pri" style="width:100%" id="pb">Place order · ${inr(t.total)}</button></form>
  <div class="panel"><h3>Order summary</h3>${C.map(l => `<div class="row line"><span>${esc(find(l.id).name)} × ${l.qty}</span><span>${inr(find(l.id).price * l.qty)}</span></div>`).join('')}<div class="row line"><b>Total</b><b>${inr(t.total)}</b></div></div></div>`;
}
function tl(o) {
  const s = stage(o); if (s < 0) return '<span class="tag" style="color:var(--bad)">Cancelled</span>';
  return `<div class="tl">${ST.map((x, i) => `<div class="${i <= s ? 'd' : ''}">${x}</div>`).join('')}</div>`;
}
function vOrders() {
  const mine = O.filter(o => o.uid === S.email);
  return `<h2>My orders</h2>${Q.get('ok') ? `<div class="panel" style="border-color:var(--ac)">✅ Order placed successfully! Your order ID is <b>${esc(Q.get('ok'))}</b>.</div>` : ''}
  ${mine.length ? mine.map(o => `<div class="panel"><div class="row"><b>${o.id}</b><span class="mut">${new Date(o.created).toLocaleString()}</span></div>
  ${o.items.map(i => `<div class="line">${esc(i.name)} × ${i.qty} — ${inr(i.price * i.qty)}</div>`).join('')}<p>Total: <b>${inr(o.total)}</b> · ${esc(o.pay)} · ${esc(o.addr.city)}</p>${tl(o)}
  ${stage(o) >= 0 && stage(o) < 2 ? `<button class="dng" data-act="cancel" data-id="${o.id}">Cancel order</button>` : ''}</div>`).join('') : '<div class="empty">No orders yet.</div>'}`;
}
let adq = '';
function vAdmin() {
  if (S.role !== 'seller' && S.role !== 'admin') return '<div class="empty">Seller access only.</div>';
  const ps = P.filter(p => !adq || p.name.toLowerCase().includes(adq));
  return `<div class="row"><h2>Seller dashboard</h2><button class="pri" data-act="padd">+ Add product</button></div>
  <div class="panel"><div class="row"><b>Products (${P.length})</b><input id="adq" placeholder="Search products" value="${esc(adq)}"></div><div class="sc"><table><tr><th>Name</th><th>Price</th><th>Stock</th><th></th></tr>
  ${ps.map(p => `<tr><td>${esc(p.name)}</td><td>${inr(p.price)}</td><td>${p.stock}</td><td><button data-act="pedit" data-id="${p.id}">Edit</button> <button class="dng" data-act="pdel" data-id="${p.id}">Delete</button></td></tr>`).join('')}</table></div></div>
  <div class="panel"><b>All orders (${O.length})</b><div class="sc"><table><tr><th>ID</th><th>Total</th><th>Status</th></tr>${O.map(o => `<tr><td>${o.id}</td><td>${inr(o.total)}</td><td>${o.cancelled ? 'Cancelled' : `<select data-act="ost" data-id="${o.id}">${ST.map((x, i) => `<option value="${i}" ${stage(o) === i ? 'selected' : ''}>${x}</option>`).join('')}</select>`}</td></tr>`).join('') || '<tr><td colspan="3">No orders yet</td></tr>'}</table></div></div>`;
}
const v404 = () => '<div class="empty"><h2>404</h2>Page not found.<br><br><a href="#/"><button class="pri">Go home</button></a></div>';

/* ===== header, router ===== */
function hdr() {
  $('#cb').textContent = C.reduce((s, l) => s + l.qty, 0) || ''; $('#wb').textContent = W.length || '';
  $('#ua').innerHTML = S ? `<a href="#/orders">Orders</a>${S.role !== 'customer' ? '<a href="#/admin">Dashboard</a>' : ''}<a href="#" data-act="logout">Logout (${esc(S.name.split(' ')[0])})</a>` : '<a href="#/login">Login</a>';
  $('#sc').innerHTML = '<option value="">All categories</option>' + Object.keys(CATS).map(c => `<option ${F.cat === c ? 'selected' : ''}>${esc(c)}</option>`).join('');
}
function route() {
  const [path, qs] = (location.hash.slice(1) || '/').split('?'); Q = new URLSearchParams(qs || '');
  const parts = path.split('/').filter(Boolean), v = parts[0] || 'home';
  if (v === 'home') { F.q = Q.get('q') || ''; F.cat = Q.get('cat') || ''; $('#sq').value = F.q; }
  if (['checkout', 'orders', 'admin'].includes(v) && !S) { next = location.hash; mode = 'login'; location.hash = '#/login'; return; }
  const views = {home:vHome, product:() => vProduct(parts[1]), cart:vCart, wishlist:vWish, login:vAuth, checkout:vCheckout, orders:vOrders, admin:vAdmin};
  $('#app').innerHTML = (views[v] || v404)(); hdr(); window.scrollTo(0, 0);
  document.title = 'MarketNest' + (v === 'home' ? '' : ' · ' + v);
}
const rerender = () => { $('#app').innerHTML = location.hash.startsWith('#/product') ? vProduct(location.hash.split('/')[2]) : location.hash === '#/cart' ? vCart() : location.hash === '#/wishlist' ? vWish() : location.hash === '#/admin' ? vAdmin() : location.hash === '#/orders' ? vOrders() : vHome(); hdr(); };
addEventListener('hashchange', route);

/* ===== validation ===== */
function errs(form, e) { form.querySelectorAll('[data-e]').forEach(s => s.textContent = e[s.dataset.e] || ''); return !Object.keys(e).length; }

/* ===== events ===== */
document.addEventListener('click', ev => {
  const el = ev.target.closest('[data-act]'); if (!el) { if (!ev.target.closest('.sf')) $('#sg').hidden = true; return; }
  const a = el.dataset.act, id = el.dataset.id;
  if (a === 'add') add(id);
  if (a === 'buy') { add(id); if (C.find(l => l.id === id)) location.hash = '#/checkout'; }
  if (a === 'move') { add(id); W = W.filter(x => x !== id); save(); rerender(); }
  if (a === 'wish') { W = W.includes(id) ? W.filter(x => x !== id) : [...W, id]; save(); rerender(); toast(W.includes(id) ? 'Added to wishlist' : 'Removed from wishlist'); }
  if (a === 'qty') { const l = C.find(x => x.id === id), n = l.qty + +el.dataset.d; if (n < 1) return; if (n > find(id).stock) return toast('Only ' + find(id).stock + ' in stock'); l.qty = n; save(); rerender(); }
  if (a === 'rm') { C = C.filter(x => x.id !== id); save(); rerender(); }
  if (a === 'coupon') { const v = $('#cp').value.trim().toUpperCase(); if (v === 'WELCOME10') { coupon = v; toast('Coupon applied: 10% off'); } else { coupon = ''; toast('Invalid coupon'); } rerender(); }
  if (a === 'cat') { location.hash = '#/?cat=' + encodeURIComponent(el.dataset.v) + (F.q ? '&q=' + encodeURIComponent(F.q) : ''); }
  if (a === 'clear') { F = {q:'', cat:'', max:0, rating:0, sort:'rel'}; location.hash = '#/'; rerender(); }
  if (a === 'mode') { ev.preventDefault(); mode = mode === 'login' ? 'signup' : 'login'; $('#app').innerHTML = vAuth(); }
  if (a === 'showpw') document.querySelector('[name=pass]').type = el.checked ? 'text' : 'password';
  if (a === 'demo') { login(U[0]); }
  if (a === 'logout') { ev.preventDefault(); S = null; save(); toast('Logged out'); location.hash = '#/'; hdr(); }
  if (a === 'cancel') { const o = O.find(x => x.id === id); o.cancelled = true; o.items.forEach(i => { const p = find(i.id); if (p) p.stock += i.qty; }); save(); toast('Order cancelled'); rerender(); }
  if (a === 'padd') pform(); if (a === 'pedit') pform(find(id));
  if (a === 'pdel' && confirm('Delete this product?')) { P = P.filter(p => p.id !== id); W = W.filter(x => x !== id); save(); toast('Product deleted'); rerender(); }
});
document.addEventListener('change', ev => {
  const f = ev.target.dataset.f; if (f) { F[f] = f === 'sort' ? ev.target.value : +ev.target.value; rerender(); }
  if (ev.target.dataset.act === 'ost') { const o = O.find(x => x.id === ev.target.dataset.id); o.manual = +ev.target.value; save(); toast('Status updated'); }
});
document.addEventListener('input', ev => { if (ev.target.id === 'adq') { adq = ev.target.value.toLowerCase(); const p = ev.target.selectionStart; rerender(); const i = $('#adq'); i.focus(); i.setSelectionRange(p, p); } });
$('#sf').addEventListener('submit', ev => { ev.preventDefault(); $('#sg').hidden = true; const q = $('#sq').value.trim(), c = $('#sc').value; location.hash = '#/?q=' + encodeURIComponent(q) + (c ? '&cat=' + encodeURIComponent(c) : ''); });
let dt; $('#sq').addEventListener('input', () => { clearTimeout(dt); dt = setTimeout(() => {
  const q = $('#sq').value.trim(), g = $('#sg'); if (!q) { g.hidden = true; return; }
  const r = P.filter(p => match(p, q)).slice(0, 5);
  g.innerHTML = r.length ? r.map(p => `<a href="#/product/${p.id}">${p.icon} ${esc(p.name)} <b>${inr(p.price)}</b></a>`).join('') : '<a href="#/">No suggestions</a>'; g.hidden = false; }, 250); });

function login(u) { S = {name:u.name, email:u.email, role:u.role}; save(); toast('Welcome, ' + u.name.split(' ')[0]); const n = next || '#/'; next = ''; location.hash = n; hdr(); }
document.addEventListener('submit', ev => {
  const f = ev.target;
  if (f.id === 'af') {
    ev.preventDefault(); const d = Object.fromEntries(new FormData(f)), e = {}, em = (d.email || '').trim().toLowerCase();
    if (mode === 'signup' && (d.name || '').trim().length < 2) e.name = 'Enter your name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) e.email = 'Enter a valid email.';
    if ((d.pass || '').length < 6) e.pass = 'Password must be at least 6 characters.';
    if (!errs(f, e)) return;
    const u = U.find(x => x.email === em);
    if (mode === 'signup') { if (u) return errs(f, {email:'This email is already registered.'}); const nu = {name:d.name.trim(), email:em, pass:btoa(d.pass), role:'customer'}; U.push(nu); save(); login(nu); }
    else { if (!u || u.pass !== btoa(d.pass)) return errs(f, {pass:'Wrong email or password.'}); login(u); }
  }
  if (f.id === 'co') {
    ev.preventDefault(); const d = Object.fromEntries(new FormData(f)), e = {};
    if (d.name.trim().length < 3) e.name = 'Enter your full name.';
    if (!/^[6-9]\d{9}$/.test(d.phone)) e.phone = 'Enter a valid 10-digit mobile number.';
    if (!/^\d{6}$/.test(d.pin)) e.pin = 'Enter a 6-digit pincode.';
    if (d.addr.trim().length < 6) e.addr = 'Enter your full address.';
    if (d.city.trim().length < 2) e.city = 'Enter your city.';
    if (!errs(f, e)) return;
    const b = $('#pb'); b.disabled = true; b.textContent = 'Processing payment…'; $('#pe').textContent = '';
    setTimeout(() => {
      if (d.pay !== 'Cash on Delivery' && Math.random() < .1) { b.disabled = false; b.textContent = 'Retry payment'; $('#pe').textContent = 'Payment failed (demo). Please retry.'; return; }
      const t = tot(), id = 'MN' + Date.now().toString().slice(-8);
      O.unshift({id, uid:S.email, items:C.map(l => ({id:l.id, name:find(l.id).name, price:find(l.id).price, qty:l.qty})), total:t.total, addr:{name:d.name, phone:d.phone, pin:d.pin, addr:d.addr, city:d.city}, pay:d.pay, created:Date.now()});
      C.forEach(l => find(l.id).stock -= l.qty); C = []; coupon = ''; save(); location.hash = '#/orders?ok=' + id; hdr();
    }, 800);
  }
  if (f.id === 'pf') {
    ev.preventDefault(); const d = Object.fromEntries(new FormData(f)), e = {};
    if (d.name.trim().length < 3) e.name = 'Name needs at least 3 characters.';
    if (d.brand.trim().length < 2) e.brand = 'Enter a brand.';
    if (!(+d.price > 0)) e.price = 'Price must be above 0.';
    if (!(+d.mrp >= +d.price)) e.mrp = 'MRP must be at least the price.';
    if (!/^\d+$/.test(d.stock)) e.stock = 'Enter a whole number (0 or more).';
    if (!errs(f, e)) return;
    const data = {name:d.name.trim(), brand:d.brand.trim(), cat:d.cat, icon:CATS[d.cat], price:+d.price, mrp:+d.mrp, stock:+d.stock, tags:(d.tags || '').toLowerCase()};
    if (editId) { Object.assign(find(editId), data); toast('Product updated'); }
    else { P.unshift({id:'p' + Date.now(), rating:4.0, seller:S.name, desc:data.name + ' by ' + data.brand + '. Sold on MarketNest.', ...data}); toast('Product added'); }
    save(); $('#dlg').close(); rerender();
  }
});
function pform(p) {
  editId = p ? p.id : ''; const v = k => p ? esc(p[k]) : '';
  $('#pf').innerHTML = `<h2>${p ? 'Edit' : 'Add'} product</h2>${[['name', 'Name'], ['brand', 'Brand'], ['price', 'Price (₹)'], ['mrp', 'MRP (₹)'], ['stock', 'Stock'], ['tags', 'Search tags (optional)']].map(([k, l]) => `<div class="f"><label>${l}</label><input name="${k}" value="${v(k)}"><small class="err" data-e="${k}"></small></div>`).join('')}
  <div class="f"><label>Category</label><select name="cat">${Object.keys(CATS).map(c => `<option ${p && p.cat === c ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select></div>
  <div class="row"><button type="button" onclick="document.getElementById('dlg').close()">Cancel</button><button class="pri">Save product</button></div>`;
  $('#dlg').showModal();
}
route();
